import java.util.*;

public interface MessageLogger {
  public void logMsg(String msg);
}
