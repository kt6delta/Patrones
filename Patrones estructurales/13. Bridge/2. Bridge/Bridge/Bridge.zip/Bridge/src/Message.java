import java.util.*;

public interface Message {
  public void log(String msg);
}
